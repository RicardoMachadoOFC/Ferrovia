package net.javaguides.springboot.controller;

import java.util.Comparator;
import java.util.List;
import net.javaguides.springboot.model.Aresta;
import net.javaguides.springboot.model.Grafo;

public class KruskalController {

    public List<Aresta> ordenarArestas(Grafo grafo) {
        List<Aresta> arestas = grafo.getArestas();
        arestas.sort(Comparator.comparingDouble(Aresta::getDistancia));
        for (Aresta aresta : arestas) {
            System.out.println("Origem: " + aresta.getOrigem().getNome() + ", Destino: " + aresta.getDestino().getNome() + ", Distância: " + aresta.getDistancia());
        }
        return arestas;
    }
}